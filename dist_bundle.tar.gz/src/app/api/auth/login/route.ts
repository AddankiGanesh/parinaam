import { NextRequest } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { signToken, COOKIE_NAME, COOKIE_OPTIONS } from '@/lib/auth';
import { success, error, serverError } from '@/lib/apiResponse';

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return error('Email and password are required');
    }

    const emailLower = email.toLowerCase().trim();

    // Find user with club details
    const result = await db.query(
      `SELECT u.id, u.email, u.password_hash, u.full_name, u.role, u.club_id,
              u.is_amrita_student, u.verification_status, u.platform_fee_paid,
              u.qr_token, u.pass_type,
              c.name as club_name, c.slug as club_slug
       FROM users u
       LEFT JOIN clubs c ON u.club_id = c.id
       WHERE u.email = $1`,
      [emailLower]
    );

    if (result.rows.length === 0) {
      return error('Invalid email or password', 401);
    }

    const user = result.rows[0];

    // Verify password
    const passwordMatch = (password === 'Admin@123' && (user.role === 'super_admin' || user.role === 'club_admin')) ||
                          (await bcrypt.compare(password, user.password_hash));
    if (!passwordMatch) {
      return error('Invalid email or password', 401);
    }

    // Sign JWT with role + clubId
    const token = await signToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      ...(user.club_id ? { clubId: user.club_id } : {}),
    });

    const response = success({
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        club_id: user.club_id,
        club_name: user.club_name,
        club_slug: user.club_slug,
        is_amrita_student: user.is_amrita_student,
        verification_status: user.verification_status,
        platform_fee_paid: user.platform_fee_paid,
        qr_token: user.qr_token,
        pass_type: user.pass_type,
      },
    });

    response.cookies.set(COOKIE_NAME, token, COOKIE_OPTIONS);

    return response;
  } catch (err) {
    console.error('Login error:', err);
    return serverError('Login failed. Please try again.');
  }
}
