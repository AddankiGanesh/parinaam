'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function PronitesPage() {
  const router = useRouter();
  useEffect(() => {
    router.replace('/events');
  }, [router]);
  return null;
}
